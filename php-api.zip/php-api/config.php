<?php
// Basic configuration for PHP API.
// Prefer environment variables in production. These are fallbacks.

return [
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'insights',
  'DB_USER' => 'root',
  'DB_PASSWORD' => '',
  'DB_PORT' => '3306',
];

